function y_predict = weightedKNN(X_train,y_train,X_test,sigma)

class=zeros(size(X_test,1),max(y_train));

for(n=1:size(X_test,1))
   
    for(i=1:size(X_train))
       w=exp(-(pdist2(X_test(n),X_train(i)))^2/(sigma^2));
       class(n,y_train(i))=class(n,y_train(i))+w*1;
    end
    [M,I]=max(class(n,:));
    y_predict(n,1)=I;
end
end