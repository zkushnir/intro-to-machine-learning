%Homework 5
clc;clear;
%Problem 1
load("input/hw4_data3.mat");
sigma=[.01 .05 .2 1.5 3.2 5];
acc=zeros(1,length(sigma));
for(i=1:length(sigma))
    y_predict=weightedKNN(X_train,y_train,X_test,sigma(i));
    for(n=1:size(y_predict,1))
        if(y_test(n)==y_predict(n))
            acc(i)=acc(i)+1;
        end
    end
    acc(i)=acc(i)/size(y_predict,1);
end
figure;
plot(sigma,acc);
xlabel("Sigma");
ylabel("Accuracy");
Accuracy=acc

clear all; 

%Problem 2
%2.0
organizeImages();
imshow(imread('input/train/1_1.pgm'))

%2.1
%a
P = 'C:\Users\zskus\iCloudDrive\Pitt\8_Senior_Fall\Machine Learning\HW\HW5\ps5_matlab_Kushnir_Zachary\input\train';
D = dir(fullfile(P,'*.pgm'));
C = cell(size(D));
tmatrix=zeros(10304,320);
for k = 1:numel(D)
    a = imread(fullfile(P,D(k).name));
    a=reshape(a,[],1);
    tmatrix(:,k)=a;
end
figure;
imshow(tmatrix,[]);

%b
meanface=mean(tmatrix,2);
meanfacereshaped=reshape(meanface,112,92);
figure;
imshow(meanfacereshaped,[]);

%c
Amatrix=zeros(size(tmatrix));
for(i=1:size(tmatrix,2))
    A(:,i)=tmatrix(:,i)-meanface;
end
C=A*A';
figure;
imshow(C);

%d
e=eig(C);
esort=sort(e,'descend');
esum2=sum(esort);
esum1=0;
%k=zeros(length(esort),1);
%v=zeros(length(esort),1);
for(i=1:length(e))
    k(i)=i;
    esum1=esum1+esort(i);
    v(i)=esum1/esum2;
end
figure;
plot(k,v);
xlabel('k');
ylabel('V');
kval=0;
for(i=1:length(v))
   if(v(i)>=0.95)
        kval=i;
        break;
   end
end
MaxK=kval

%e
[U,D]=eigs(C,kval);
figure;
for(i=1:9)
    subplot(3,3,i);
    imshow(reshape(U(:,i),112,92),[]);
end
size(U)

%2.2
%a
count=1;
yval=1;
for(i=1:size(tmatrix,2))
    w=U'*(tmatrix(:,i)-meanface);
    W_training(i,:)=w';
    y_train(i,1)=yval;
    if(8/count==1)
        count=1;
        yval=yval+1;
    else
        count=count+1;
    end
end
P = 'C:\Users\zskus\iCloudDrive\Pitt\8_Senior_Fall\Machine Learning\HW\HW5\ps5_matlab_Kushnir_Zachary\input\test';
D = dir(fullfile(P,'*.pgm'));
C = cell(size(D));
aa=zeros(10304,numel(D));
count=1;
yval=1;
for k = 1:numel(D)
    a = imread(fullfile(P,D(k).name));
    a=reshape(a,[],1);
    aa(:,k)=a;
    w=U'*(aa(:,k)-meanface);
    W_testing(k,:)=w';
    y_test(k,1)=yval;
    if(2/count==1)
        yval=yval+1;
        count=1;
    else
        count=count+1;
    end
end
size(W_training)
size(W_testing)

%2.3
%a
kval=[1 3 5 7 9 11];
acc=zeros(1,length(kval));
for(k=1:length(kval))
    mdl=fitcknn(W_training,y_train,'NumNeighbors',kval(k));
    y_pred=predict(mdl,W_testing);
    for(i=1:size(y_pred,1))
        if(y_pred(i)==y_test(i))
            acc(k)=acc(k)+1;
        end
    end
    acc(k)=acc(k)/length(y_pred);
end
% figure;
% plot(kval,acc);
Accuracy=acc

%b
%one vs all training
classes=unique(y_train);
ms=length(classes);
timemdl=zeros(numel(classes),3);
timepred=zeros(numel(classes),3);
kerneltype=["linear","polynomial","rbf"];
for(c=1:3)%loop through three kernel types
    SVMModels=zeros(ms,1);
    for(i=1:numel(classes))%loop through one vs all classes
        ytr=y_train;
        for(j=1:length(y_train))
            if(ytr(j)~=i)
                ytr(j)=0;
            end
        end
        tic
        mdl=fitcsvm(W_training,ytr,'Standardize',true,'KernelFunction',kerneltype(c));
        timemdl(i,c)=toc;%record class training time
        tic
        [~,score]=predict(mdl,W_testing);
        timepred(i,c)=toc;%record class testing time
        Scores(:,i)=score(:,2);
    end
    [~,y_pred(:,c)]=max(Scores,[],2);%predict y values
    
end
%loop through to determine accuracy
acc=[0,0,0]; 
for(c=1:3)
    for(i=1:size(y_pred,1))
        if(y_pred(i,c)==y_test(i))
            acc(c)=acc(c)+1;
        end
    end
    acc(c)=acc(c)/length(y_pred(:,c));
end
%Display time and accuracy for linear polynomial and rbf kernel resp. 
ClassifierTime=sum(timemdl,1)
PredictTime=sum(timepred,1)
Accuracy=acc

%one vs one 
classes=unique(y_train);
ms=length(classes);
timemdl=zeros(numel(classes),3);
timepred=zeros(numel(classes),3);
kerneltype=["linear","polynomial","rbf"];
Scores=zeros(80,40);
for(c=1:3)%loop through three kernel types
    SVMModels=zeros(ms,1);
    for(i=1:numel(classes))%loop through one vs all classes
       for(x=i+1:numel(classes))%start with 1 vs 2 (1+1)
           ytr=[];
           xtr=[];
           count=1;
           for(j=1:length(y_train))%find data with 1 and 2 only
            if(y_train(j)==i)
                ytr(count,1)=1;
                xtr(count,:)=W_training(j,:);
                count=count+1;
            elseif(y_train(j)==x)
                ytr(count,1)=0;
                xtr(count,:)=W_training(j,:);
                count=count+1;
            end
        end
        tic
        mdl=fitcsvm(xtr,ytr,'Standardize',true,'KernelFunction',kerneltype(c));
        timemdl(i,c)=timemdl(i,c)+toc;%record class training time
        
        tic
        [~,score]=predict(mdl,W_testing);
        timepred(i,c)=timepred(i,c)+toc;%record classtesting time
        for(s=1:length(score(:,2)))
            if(score(s,2)>=.5)
                Scores(s,i)=Scores(s,i)+1;
            else
                Scores(s,x)=Scores(s,x)+1;
            end
        end
       end
    end
    [~,y_pred(:,c)]=max(Scores,[],2);%predict y values
    
end
%loop through to determine accuracy
acc=[0,0,0]; 
for(c=1:3)
    for(i=1:size(y_pred,1))
        if(y_pred(i,c)==y_test(i))
            acc(c)=acc(c)+1;
        end
    end
    acc(c)=acc(c)/length(y_pred(:,c));
end
%Display time and accuracy for linear polynomial and rbf kernel resp. 
ClassifierTime2=sum(timemdl,1)
PredictTime2=sum(timepred,1)
Accuracy2=acc