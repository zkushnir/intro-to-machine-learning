function []=organizeImages()
   
    for(i=1:40)
       idx=randperm(10);
       for(n=1:8)
           filename=strcat("input/all/s",num2str(i),"/",num2str(idx(n)),".pgm");
           location=strcat("input/train/",num2str(i),"_",num2str(n),".pgm");
           movefile(filename,location);
       end
       filename=strcat("input/all/s",num2str(i),"/",num2str(idx(9)),".pgm");
       location=strcat("input/test/",num2str(i),"_",num2str(1),".pgm");
       movefile(filename,location);
       filename=strcat("input/all/s",num2str(i),"/",num2str(idx(10)),".pgm");
       location=strcat("input/test/",num2str(i),"_",num2str(2),".pgm");
       movefile(filename,location);
    end
end